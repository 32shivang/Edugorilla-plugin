<?php
function wpsh_textfields($contents){
	$content = require plugin_dir_path(__FILE__).'main.php';
	$button='<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">INTERNSHIP PROJECT</button>';
	$contents .=$button;
	$contents .=$content;
	$contents;
	//$text1=get_option("name-label",'');
	//$text2=get_option("email-label",'');
	/*$text_wrap_start='<div class="wrap-container">';
	$name='<input  class="name" type="text" placeholder="Enter Your Name"><br><br>';
	$email='<input  class="email" type="email" placeholder="Enter Your Email"><br><br>';
	$button='<button type="button" class="btn btn-success">SUBMIT</button>';
	$text_wrap_stop='</div>';
	$contents .=$text_wrap_start;
	$contents .=$name;
	$contents .=$email;
	$contents .=$button;
	$contents .=$text_wrap_stop;*/
	
	return $contents;
	}

	add_filter("the_content","wpsh_textfields");
	?>