<?php
function wpsh_fun(){
	if(!is_admin()){
		return;
		}
			?>
			<h1>Description</h1>
	<h3>Hello welcome to my project of edugorilla... I really like this project as it is my first time I am making my own plugin. I want to learn more through your projects </h3>
	<h3>Please see your webpage to see the changes done by my plugin. See the right top corner of your webpage you will see the button of Internship Project and that button gives you a modal Through which you can eter the deatails.</h3>
	<?php
}

/*function wpsh_settings_fun(){
	register_setting("wpsh-setings","name-label");
	register_setting("wpsh-setings","email-label");
	//register_setting("wpsh-setings","button");
	add_settings_section("label","WPSH BUTTON","wpsh_callback","wpsh-setings");
	add_settings_field("name-label","Name","wpsh_callback1","wpsh-setings","label");
	add_settings_field("email-label","Email","wpsh_callback2","wpsh-setings","label");
	//add_settings_field("button","Submit","wpsh_callback1","wpsh-setings","label");
}
add_action("admin_init","wpsh_settings_fun");
function wpsh_callback(){
	echo "Hello";
}
function wpsh_callback1(){
	// get the value of the setting we've registered with register_setting()
    $setting = get_option('Name');
?>
<input type="text" name="name" value="<?php echo isset( $setting ) ? esc_attr( $setting ) : ''; ?>">
<?php
}
function wpsh_callback2(){
	// get the value of the setting we've registered with register_setting()
	$setting1 = get_option('email-label');
    // output the field
    ?>
    <input type="text" name="email" value="<?php echo isset( $setting1 ) ? esc_attr( $setting1 ) : ''; ?>">
    <?php
}*/
?>