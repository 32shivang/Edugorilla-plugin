<!DOCTYPE html>
<html lang="en">
<head>
  <title> </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>
<style>
	
.wrap-container{
position:absolute;
right:60px;
top:30px;

}
</style>
<body>

<div class=" wrap-container">

  <!-- Button to Open the Modal -->
 <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
    INTERNSHIP PROJECT
  </button>

  <!-- The Modal -->
  <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content"> 
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Enter Your Details</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div> 
        
        <!-- Modal body--> 
        <div class="modal-body"> 
		<form method="POST" id="insert_form"action="wp-content/plugins/edugorilla_plugin/inc/blank_of_data.php">
          <input type="text" placeholder="Enter Name" class="form-control"  name="first"> <br>
		  <input type="email" placeholder="Enter email" class="form-control" name="second"><br>
		  <input value="Login" type="submit" name="submit" class="form-control" />
        </form>
		</div>
        
        <!--Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		  
        </div>
        
      </div>
    </div>
  </div>
  
</div>
<script>
/*$(document).ready(function(){
	$('#insert_form').on('submit',function(){
	event.preventDefault();
	 if($('#name').value == " "){
	 alert("Enter Name");
	 }		 
	if($('#email').value == " "){
	alert("Enter Email");
	}	
	 if($('#email').value != "/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/") {
	 alert("Enter correct email");
	 }
	 });
});*/
</script>
<?php
if(isset($_POST["submit"]))
{
	
$servername = "localhost";
$username = "root";
$password = "srivastava08";
$dbname = "edugorilla";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	echo "<script>alert('NOT CONNECTED');</script>";
	
    die("Connection failed: " . $conn->connect_error);
} 
    $name = mysqli_real_escape_string($conn, $_POST["first"]); 
	$email = mysqli_real_escape_string($conn, $_POST["second"]); 
	

     $query = ("INSERT INTO wpsh_intern values('$name','$email')");

if(mysqli_query($conn,$query))
 {
echo "<script>alert('WELCOME $name INSERTION IS SUCCESSFULL');</script>";
}
else
 {
 echo "<script>alert('Data Already Exist');</script>";
 }

$conn->close();

	}
	
?>
</body>
</html>
