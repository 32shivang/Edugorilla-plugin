<?php
/**
 * @package Hello_Dolly
 * @version 1.7.1
 */
/*
Plugin Name: edugorilla_plugin
Plugin URI:www.gamebeaus.com
Description: This is my plugin for edugorilla and it will contain text fields as name and email.
Author: Shivang Srivastava
Version: 1.7.1
Author URI: www.gamebeaus.com
*/
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <?php

function test(){
add_menu_page("Edugorilla","Edugorilla_plugin","manage_options","wpsh-setings","wpsh_fun","dashicons-thumbs-up",5);
//add_submenu_page("tools.php","wpsh-setings","Edugorilla_plugin","manage_options","wpsh_fun",5);
//add_options_page("submenu1","Edugorilla_plugin","manage_options","wpsh-setings","wpsh_fun",5);//only add to the setting page
//add_theme_page("submenu1","Edugorilla_plugin","manage_options","wpsh-setings","wpsh_fun",5);//only add to the theme page
}
add_action("admin_menu","test");
if( ! defined('WPINC') )
	die('Not allowed');

if(!function_exists('wpsh_first')){
function wpsh_first(){
}
}	
if(!defined('WPSH_PLUGIN_DIR')){
	define('WPSH_PLUGIN_DIR',plugin_dir_url(__FILE__));
}
if(!function_exists('wpsh_edu')){
	
function wpsh_edu(){
	wp_enqueue_style('wpsh-css',WPSH_PLUGIN_DIR.'assets/css/page.css');
	
	}
add_action('wp_enqueue_scripts','wpsh_edu');
}
require plugin_dir_path(__FILE__).'inc/setting.php';
require plugin_dir_path(__FILE__).'inc/create_table.php';
//$content = require plugin_dir_path(__FILE__).'main.php';

function wpsh_textfields($contents){
	$content = require plugin_dir_path(__FILE__).'main.php';
	//$button='<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">INTERNSHIP PROJECT</button>';
	//$contents .=$button;
	$contents .=$content;
	$contents;
	//$text1=get_option("name-label",'');
	//$text2=get_option("email-label",'');
	/*$text_wrap_start='<div class="wrap-container">';
	$name='<input  class="name" type="text" placeholder="Enter Your Name"><br><br>';
	$email='<input  class="email" type="email" placeholder="Enter Your Email"><br><br>';
	$button='<button type="button" class="btn btn-success">SUBMIT</button>';
	$text_wrap_stop='</div>';
	$contents .=$text_wrap_start;
	$contents .=$name;
	$contents .=$email;
	$contents .=$button;
	$contents .=$text_wrap_stop;*/
	
	return $contents;

	}
	add_filter("the_content","wpsh_textfields");



?>	